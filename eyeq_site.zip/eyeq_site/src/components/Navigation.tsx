import React, { useState } from 'react';
import { Home, Mail, Trophy, Calendar, Menu, X, CreditCard, HelpCircle, User, Eye } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
}

export const Navigation: React.FC<NavigationProps> = ({ currentPage, onNavigate }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const { isAuthenticated, user } = useAuth();

  const menuItems = [
    { id: 'home', icon: Home, label: 'Home' },
    { id: 'contact', icon: Mail, label: 'Contact' },
    { id: 'faq', icon: HelpCircle, label: 'FAQ' },
    { id: 'leaderboard', icon: Trophy, label: 'Leaderboard' },
    { id: 'events', icon: Calendar, label: 'Events' },
    { id: 'id-generator', icon: CreditCard, label: 'Create ID' },
  ];

  const handleNavigate = (page: string) => {
    if (['leaderboard', 'events', 'id-generator'].includes(page) && !isAuthenticated) {
      onNavigate('auth');
    } else {
      onNavigate(page);
    }
    setIsExpanded(false);
  };

  return (
    <>
      <nav
        className={`navigation ${isExpanded ? 'expanded' : 'collapsed'}`}
        onMouseEnter={() => setIsExpanded(true)}
        onMouseLeave={() => setIsExpanded(false)}
      >
        <div className="nav-toggle">
          {isExpanded ? <X size={24} /> : <Menu size={24} />}
        </div>

        <div className="nav-content">
          <div className="nav-logo">
            <Eye className="nav-logo-icon" />
            <span className="nav-title">EyeQ Club</span>
          </div>

          <div className="nav-items">
            {menuItems.map((item) => (
              <button
                key={item.id}
                className={`nav-item ${currentPage === item.id ? 'active' : ''}`}
                onClick={() => handleNavigate(item.id)}
              >
                <item.icon size={24} />
                <span className="nav-label">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </nav>

      <div className="profile-section">
        <button
          className="profile-button"
          onClick={() => onNavigate(isAuthenticated ? 'profile' : 'auth')}
        >
          {isAuthenticated ? (
            <div className="profile-avatar">
              {user?.fullName.charAt(0).toUpperCase()}
            </div>
          ) : (
            <User size={24} />
          )}
        </button>
      </div>
    </>
  );
};
